import pickle
from flask import Flask , request, render_template
app = Flask(__name__)
model = pickle.load(open("sarima.pkl","rb"))
@app.route('/')
def indput():
    return render_template('index.html')

@app.route('/predict',methods = ['GET','POST'])
def admin():
    year=eval(request.form["year"])
    print(year)
    xx=model.predict(str(year))
    out=int(xx[0])

    print('Forecasted production is {0:.1f} tonnes'.format(out))
    
    return render_template("index.html",p='Forecasted production of {} is {} tonnes'.format(year,out))
if __name__ == '__main__':
    app.run(debug = False, port=4000)